from django.urls import path
from django.conf.urls import include, url
from my_hello_world.views import foo
# import views from local directory.
from . import views
urlpatterns = [
    path('', views.index_page, name='index'),
    url(r'HelloWorldApp/$', foo),
]